﻿using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Application.DTOs;
using FileUploadSystem.Domain.Entities;

namespace FileUploadSystem.Infrastructure.Services
{
    public class UploadedFileService : IUploadedFileService
    {
        private readonly IUploadedFileRepository _uploadedFileRepository;

        public UploadedFileService(IUploadedFileRepository uploadedFileRepository)
        {
            _uploadedFileRepository = uploadedFileRepository;
        }

        public async Task<UploadedFileDto> UploadFileAsync(UploadedFileDto fileDto)
        {
            // Dosya yükleme işlemi ve dönüş
            var uploadedFile = new UploadedFile
            {
                FileName = fileDto.FileName,
                FilePath = fileDto.FilePath,
                UploadDate = fileDto.UploadDate
            };

            await _uploadedFileRepository.AddAsync(uploadedFile);

            fileDto.Id = uploadedFile.Id;
            return fileDto;
        }

        // Diğer servis metodları burada yer alabilir
    }
}
