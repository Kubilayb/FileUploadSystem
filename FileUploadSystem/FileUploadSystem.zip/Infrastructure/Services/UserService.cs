﻿using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Application.DTOs;
using FileUploadSystem.Domain.Entities;

namespace FileUploadSystem.Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<UserDto> RegisterUserAsync(UserDto userDto)
        {
            // Kullanıcı kayıt işlemi ve dönüş
            var user = new User
            {
                UserName = userDto.UserName,
                Email = userDto.Email,
                PasswordHash = userDto.PasswordHash,
                PasswordSalt = userDto.PasswordSalt
            };

            await _userRepository.AddAsync(user);

            userDto.Id = user.Id;
            return userDto;
        }

        // Diğer servis metodları burada yer alabilir
    }
}
