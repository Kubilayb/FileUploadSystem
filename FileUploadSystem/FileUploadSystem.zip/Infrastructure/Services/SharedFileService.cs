﻿using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Application.DTOs;
using FileUploadSystem.Domain.Entities;

namespace FileUploadSystem.Infrastructure.Services
{
    public class SharedFileService : ISharedFileService
    {
        private readonly ISharedFileRepository _sharedFileRepository;

        public SharedFileService(ISharedFileRepository sharedFileRepository)
        {
            _sharedFileRepository = sharedFileRepository;
        }

        public async Task<SharedFileDto> ShareFileAsync(SharedFileDto sharedFileDto)
        {
            // Dosya paylaşma işlemi ve dönüş
            var sharedFile = new SharedFile
            {
                FileId = sharedFileDto.FileId,
                UserId = sharedFileDto.UserId,
                SharedDate = sharedFileDto.SharedDate
            };

            await _sharedFileRepository.AddAsync(sharedFile);

            sharedFileDto.Id = sharedFile.Id;
            return sharedFileDto;
        }

        // Diğer servis metodları burada yer alabilir
    }
}
