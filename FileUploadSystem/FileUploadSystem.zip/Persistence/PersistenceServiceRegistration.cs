﻿using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Persistence.Contexts;
using FileUploadSystem.Persistence.Repositories;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace FileUploadSystem.Persistence
{
    public static class PersistenceServiceRegistration
    {
        public static void AddPersistenceServices(this IServiceCollection services)
        {
            // Add DbContext
            services.AddDbContext<FileUploadDbContext>(options =>
                options.UseSqlServer("Server=localhost,1433;Database=FileUploadSystemDB;User Id=sa;Password=YourStrongPassword123!;TrustServerCertificate=True"));

            // Add scoped services
            services.AddScoped<IUploadedFileService, UploadedFileService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ISharedFileService, SharedFileService>();
            services.AddScoped<IUploadedFileRepository, UploadedFileRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ISharedFileRepository, SharedFileRepository>();
        }
    }
}
