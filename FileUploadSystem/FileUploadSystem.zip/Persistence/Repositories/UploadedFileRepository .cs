﻿using Core.DataAccess;
using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Domain.Entities;
using FileUploadSystem.Persistence.Contexts;

public class UploadedFileRepository : EfRepositoryBase<UploadedFile, FileUploadDbContext>, IUploadedFileRepository
{
    public UploadedFileRepository(FileUploadDbContext context) : base(context)
    {
    }
}