﻿using Core.DataAccess;
using FileUploadSystem.Application.Interfaces;
using FileUploadSystem.Domain.Entities;
using FileUploadSystem.Persistence.Contexts;

namespace FileUploadSystem.Persistence.Repositories
{
    public class UserRepository : EfRepositoryBase<User, FileUploadDbContext>, IUserRepository
    {
        public UserRepository(FileUploadDbContext context) : base(context)
        {
        }
    }
}
