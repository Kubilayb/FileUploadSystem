﻿namespace Application.Features.UserOperationClaims.Constants
{
    public static class UserOperationClaimsMessages
    {
        public const string UserOperationClaimNotExists = "UserOperationClaim not exists.";
        public const string UserOperationClaimDeleteMsg = "Deletion Successful!";
    }
}
