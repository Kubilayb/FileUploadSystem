﻿using MediatR;
using AutoMapper;
using Application.Dtos;
using Application.Repositories;
using Core.Domain.Entities;
using Application.Features.UserOperationClaims.Rules;
using Core.CrossCuttingConcerns.Exceptions.Types;

namespace Application.Features.UserOperationClaims.Commands.Update
{
    public class UpdateUserOperationClaimCommand : IRequest<UpdateUserOperationClaimDto>
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int OperationClaimId { get; set; }
    }

    public class UpdateUserOperationClaimCommandHandler : IRequestHandler<UpdateUserOperationClaimCommand, UpdateUserOperationClaimDto>
    {
        private readonly IUserOperationClaimRepository _userOperationClaimRepository;
        private readonly IMapper _mapper;
        private readonly UserOperationClaimBusinessRules _userOperationClaimBusinessRules;

        public UpdateUserOperationClaimCommandHandler(IUserOperationClaimRepository userOperationClaimRepository, IMapper mapper, UserOperationClaimBusinessRules userOperationClaimBusinessRules)
        {
            _userOperationClaimRepository = userOperationClaimRepository;
            _mapper = mapper;
            _userOperationClaimBusinessRules = userOperationClaimBusinessRules;
        }

        public async Task<UpdateUserOperationClaimDto> Handle(UpdateUserOperationClaimCommand request, CancellationToken cancellationToken)
        {
            var userOperationClaim = await _userOperationClaimRepository.GetByIdAsync(request.Id);
            if (userOperationClaim == null) throw new NotFoundException("User operation claim not found");

            await _userOperationClaimBusinessRules.OperationClaimCannotBeDuplicatedWhenUpdated(request.UserId, request.OperationClaimId, request.Id);

            _mapper.Map(request, userOperationClaim);
            await _userOperationClaimRepository.Update
