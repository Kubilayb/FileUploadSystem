namespace Application.Features.SharedFiles.Queries.GetById
{
    public class GetByIdSharedFileQuery
    {
        public int Id { get; set; }
    }
}
