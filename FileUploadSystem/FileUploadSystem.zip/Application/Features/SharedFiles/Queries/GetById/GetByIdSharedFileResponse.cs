namespace Application.Features.SharedFiles.Queries.GetById
{
    public class GetByIdSharedFileResponse
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
}
