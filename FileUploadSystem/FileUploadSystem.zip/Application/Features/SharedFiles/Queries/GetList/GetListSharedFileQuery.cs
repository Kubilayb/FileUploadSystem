namespace Application.Features.SharedFiles.Queries.GetList
{
    public class GetListSharedFileQuery
    {
        // Add any necessary properties for filtering or pagination
    }
}
