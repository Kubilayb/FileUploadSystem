namespace Application.Features.SharedFiles.Commands.Delete
{
    public class DeleteSharedFileCommand
    {
        public int Id { get; set; }
    }
}
