namespace Application.Features.SharedFiles.Commands.Update
{
    public class UpdateSharedFileResponse
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
}
