namespace Application.Features.SharedFiles.Commands.SoftDelete
{
    public class SoftDeleteSharedFileCommand
    {
        public int Id { get; set; }
    }
}
