namespace Application.Features.UploadedFiles.Queries.GetById
{
    public class GetByIdUploadedFileQuery
    {
        public int Id { get; set; }
    }
}
