namespace Application.Features.UploadedFiles.Queries.GetList
{
    public class GetListUploadedFileQuery
    {
        // Add any necessary properties for filtering or pagination
    }
}
