namespace Application.Features.UploadedFiles.Commands.Update
{
    public class UpdateUploadedFileResponse
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
}
