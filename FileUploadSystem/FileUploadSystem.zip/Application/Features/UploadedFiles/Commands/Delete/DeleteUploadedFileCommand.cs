namespace Application.Features.UploadedFiles.Commands.Delete
{
    public class DeleteUploadedFileCommand
    {
        public int Id { get; set; }
    }
}
