namespace Application.Features.UploadedFiles.Commands.SoftDelete
{
    public class SoftDeleteUploadedFileCommand
    {
        public int Id { get; set; }
    }
}
