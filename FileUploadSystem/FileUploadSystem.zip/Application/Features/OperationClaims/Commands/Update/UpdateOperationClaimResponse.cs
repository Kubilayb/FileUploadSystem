﻿namespace Application.Features.OperationClaims.Commands.Update
{
    public class UpdateOperationClaimResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
