﻿namespace Application.Features.OperationClaims.Commands.Create
{
    public class CreateOperationClaimResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
