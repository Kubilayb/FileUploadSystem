﻿namespace Application.Features.OperationClaims.Commands.Delete
{
    public class DeleteOperationClaimResponse
    {
        public int Id { get; set; }
        public string Detail { get; set; } = "Deletion Successful!";
    }
}
