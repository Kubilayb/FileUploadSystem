﻿namespace Application.Features.OperationClaims.Constants
{
    public static class OperationClaimsMessages
    {
        public const string OperationClaimNotExists = "OperationClaim not exists.";
    }
}
