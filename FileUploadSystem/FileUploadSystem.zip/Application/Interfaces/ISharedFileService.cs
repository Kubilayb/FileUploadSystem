﻿namespace FileUploadSystem.Application.Interfaces
{
    public interface ISharedFileService
    {
        Task<SharedFileDto> ShareFileAsync(int fileId, int userId);
        Task<IEnumerable<SharedFileDto>> GetSharedFilesAsync();
    }
}
