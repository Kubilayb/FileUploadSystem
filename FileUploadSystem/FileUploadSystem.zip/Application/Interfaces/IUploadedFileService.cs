﻿using FileUploadSystem.Application.DTOs;
using Microsoft.AspNetCore.Http;

public interface IUploadedFileService
{
    Task<UploadedFileDto> UploadFileAsync(IFormFile file);
    Task<UploadedFileDto> UpdateFileAsync(int id, IFormFile file);
    Task DeleteFileAsync(int id);
    Task<IEnumerable<UploadedFileDto>> GetFilesAsync();
    Task<UploadedFileDto> GetFileByIdAsync(int id);
}