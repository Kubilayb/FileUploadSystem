﻿using Core.DataAccess;
using FileUploadSystem.Domain.Entities;

namespace FileUploadSystem.Application.Interfaces
{
    public interface IUserRepository : IRepository<User>
    {
    }
}
