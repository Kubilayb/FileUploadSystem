﻿public interface IUserService
{
    Task<UserDto> RegisterUserAsync(UserDto userDto, string password);
    Task<UserDto> LoginUserAsync(string email, string password);
}