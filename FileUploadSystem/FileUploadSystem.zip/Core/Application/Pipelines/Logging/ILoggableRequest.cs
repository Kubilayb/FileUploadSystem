﻿namespace Core.Application.Pipelines.Logging;
    public interface ILoggableRequest
    {
    }